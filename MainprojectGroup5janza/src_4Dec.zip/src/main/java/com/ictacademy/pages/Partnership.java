package com.ictacademy.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Partnership {
	WebDriver driver;
	@FindBy(xpath="//*[@id=\"dropdownMenuDocs\"]")
	private WebElement membership;
	@FindBy(xpath="//*[@id=\"navigation\"]/ul/li[4]/ul/div[2]/div/a[2]/h6")
	private WebElement cmembership;
	@FindBy(xpath="/html/body/app-root/app-home-main/app-header/div[1]/div/div/nav/div/div/ul/li[4]/ul/div[1]/ul/li[3]/a")
	private WebElement partnershp;
	@FindBy(xpath="/html/body/app-root/app-partnership/app-bannerpartnership/header/div/div[1]/div/div/button")
	private WebElement Rbutton;
	@FindBy (xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[1]/div[1]/div/input")
	private WebElement inName;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[1]/div[2]/div/input")
	private WebElement inemail;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[2]/div[1]/div/input")
	private WebElement phnum;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[2]/div[2]/div/input")
	private WebElement infirm;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[3]/div[1]/div/input")
	private WebElement inaddress;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[3]/div[2]/div/input")
	private WebElement indist;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[4]/div[1]/div/input")
	private WebElement inoffspace;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[4]/div[2]/div/input")
	private WebElement inemployees;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[5]/textarea")
	private WebElement inReport;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[6]/textarea")
	private WebElement inexpects;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[7]/textarea")
	private WebElement inpromoters;
	@FindBy(xpath="/html/body/app-root/app-partenshipform/header/div[2]/section/div/div/div/div/div[2]/form/div/div[8]/div/button")
	private WebElement sendmsg;
	
	
	public Partnership(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void clickmship() {
		Actions actions = new Actions(driver);
		actions.moveToElement(membership);
		actions.build().perform();
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void clickptship() {
		partnershp.click();
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void clickRbutton() {
		Rbutton.click();
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void fillname(String Uname) {
		inName.sendKeys(Uname);
	}
	public void fillemail(String email) {
		inemail.sendKeys(email);
	}
	public void fillphnum(String mobnum) {
		phnum.sendKeys(mobnum);
	}
	public void fillfirm(String firm) {
		infirm.sendKeys(firm);
	}
	public void filladdress(String address) {
		inaddress.sendKeys(address);
	}
	public void filldist(String dist) {
		indist.sendKeys(dist);
	}
	public void filloffspace(String offspace) {
		inoffspace.sendKeys(offspace);
	}
	public void fillemployees(String employees) {
		inemployees.sendKeys(employees);
	} 
	public void fillreport(String report) {
		inReport.sendKeys(report);
	}
	public void fillexpects(String expects) {
		inexpects.sendKeys(expects);
	}
	public void fillpromoters(String promoters) {
		inpromoters.sendKeys(promoters);
	}
	public void clksendmsg() {
		sendmsg.submit();
	}

	

}
