package com.ictacademy.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
	WebDriver driver;
	@FindBy(xpath="//a[@class=\"btn btn-sm bg-gradient-info mb-0 me-1 mt-2 mt-md-0\"]")
	private WebElement lg;
	@FindBy(xpath="//*[@id=\"exampleModalForm\"]/div/div/div/div/div[2]/form/div[1]/input")
	private WebElement uname;
	@FindBy(xpath="//*[@id=\"exampleModalForm\"]/div/div/div/div/div[2]/form/div[2]/input")
	private WebElement psw;
	@FindBy(xpath="//button[@type=\"submit\"]")
	private WebElement submit;
	@FindBy(xpath="//*[@id=\"myDiv\"]/li[3]/a")
	private WebElement testimony;
	
	public Homepage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void clickLoginbtn() {
		lg.click();
	}
	public void setUname(String username) {
		uname.sendKeys(username);
		
	}
	public void setPsw(String password) {
		psw.sendKeys(password);
		
	}
public void clicksubmit() {
		
		submit.click();
		//SendMessagebtn.sendKeys(Keys.ENTER);
		//driver.switchTo().alert().accept();
	}
public void clktestimony() {
	testimony.submit();}

}
