package com.ictacdemy.scripts;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.testng.annotations.AfterSuite;

//import org.junit.Assert;
//import org.openqa.selenium.Alert;


//import java.io.IOException;

import org.testng.annotations.Test;

import com.ictacademy.pages.Homepage;
import com.ictacademy.pages.Partnership;
//import com.ictacademy.utilities.Excelutility;

//import com.ictacademy.utilities.Excelutility;

public class Testclass extends Testbase {
	Homepage objlogin;
	Partnership objPartner;
	
	@Test
	public void clickmember() {
		objPartner= new Partnership(driver);
		objPartner.clickmship();
	}
	@Test
	public void clickpartner() {
		objPartner= new Partnership(driver);
		objPartner.clickptship();
		
	}
	@Test
	public void clkRbtn() {
		objPartner= new Partnership(driver);
		objPartner.clickRbutton();
		
	}
	@Test
	public void formfill() throws IOException {
		objPartner= new Partnership(driver);
		objPartner.fillname("Janza Rasheed");
		objPartner.fillemail("janzaanas65@gmail.com");
		objPartner.fillphnum("9895674321");
		objPartner.fillfirm("ABC Group");
		objPartner.filladdress("ABC group, Mumbai, Maharashtra, India");
		objPartner.filldist("Mumbai");
		objPartner.filloffspace("5000");
		objPartner.fillemployees("600");
		objPartner.fillreport("Increased productivity and performance");
		objPartner.fillexpects("Growing and enhanceing by technology");
		objPartner.fillpromoters("ABC group is one of the leading software devolpers in airline field");
		objPartner.clksendmsg();
		
	}

	
	@Test 
	public void verifyoutput() throws InterruptedException {
		objPartner= new Partnership(driver);
		Alert alert= driver.switchTo().alert();
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);
		Assert.assertEquals("Registration Successfull", alertMessage);
	    Thread.sleep(5000);
	    alert.accept();	
		
	}
	//@AfterSuite
	//public void Teardown() throws InterruptedException {
		//Thread.sleep(2000);
		//driver.quit();
	//}
	

}
