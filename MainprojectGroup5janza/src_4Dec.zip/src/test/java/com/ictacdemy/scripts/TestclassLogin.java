package com.ictacdemy.scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ictacademy.pages.Homepage;
//import com.ictacademy.utilities.Excelutility;

public class TestclassLogin extends Testbase{
	Homepage objLogin;
	@Test
	public void verifyLogin() throws IOException {
		objLogin= new Homepage(driver);
		objLogin.clickLoginbtn();
		objLogin.setUname("superadmin");
		objLogin.setPsw("12345");
		objLogin.clicksubmit();
	}

}

